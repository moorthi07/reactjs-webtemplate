import React from 'react';

const About = (props) => (
   <h1>About Page com</h1>
)


// function About(props){
 
// return (
//   <h1>About Page com</h1>
// )
// }

export default About;